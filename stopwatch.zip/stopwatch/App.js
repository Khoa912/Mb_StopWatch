import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList } from 'react-native';

const StopwatchApp = () => {
  const [time, setTime] = useState(0);
  const [lapTime, setLapTime] = useState(0);
  const [laps, setLaps] = useState([]);
  const [isRunning, setIsRunning] = useState(false);

  const intervalRef = useRef(null);

  useEffect(() => {
    return () => clearInterval(intervalRef.current);
  }, []);

  const toggleTimer = () => {
    if (isRunning) {
      clearInterval(intervalRef.current);
    } else {
      intervalRef.current = setInterval(() => {
        setTime((prevTime) => prevTime + 10); // Update time every 10 milliseconds
        setLapTime((prevLapTime) => prevLapTime + 10);
      }, 10);
    }

    setIsRunning(!isRunning);
  };

  const stopTimer = () => {
    clearInterval(intervalRef.current);
    setIsRunning(false);
  };

  const resetTimer = () => {
    clearInterval(intervalRef.current);
    setTime(0);
    setLapTime(0);
    setLaps([]);
    setIsRunning(false);
  };

  const lapOrResetTimer = () => {
    if (isRunning) {
      lapTimer();
    } else {
      resetTimer();
    }
  };

  const lapTimer = () => {
    setLaps((prevLaps) => [...prevLaps, lapTime]);
    setLapTime(0);
  };

  const formatTime = (milliseconds) => {
    const minutes = Math.floor(milliseconds / (60 * 1000));
    const seconds = Math.floor((milliseconds % (60 * 1000)) / 1000);
    const remainingMilliseconds = milliseconds % 1000;

    const formattedMinutes = String(minutes).padStart(2, '0');
    const formattedSeconds = String(seconds).padStart(2, '0');
    const formattedMilliseconds = String(remainingMilliseconds).slice(0, 2).padStart(2, '0');

    return `${formattedMinutes}:${formattedSeconds}:${formattedMilliseconds}`;
  };

  const renderLapItem = ({ item, index }) => (
    <Text style={styles.historyItem}>{`Lap ${index + 1}: ${formatTime(item)}`}</Text>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.clock}>{formatTime(time)}</Text>

      <View style={styles.buttonContainer}>
        <TouchableOpacity style={[styles.button, styles.lapButton]} onPress={lapOrResetTimer}>
          <Text style={styles.buttonText}>{isRunning ? 'Vòng' : 'Đặt lại'}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, styles.stopButton]} onPress={toggleTimer}>
          <Text style={styles.buttonTextstop}>{isRunning ? 'Dừng' : 'Bắt đầu'}</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.historyContainer}>
        <FlatList
          data={laps}
          renderItem={renderLapItem}
          keyExtractor={(item, index) => index.toString()}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'black',
  },
  clock: {
    color: 'white',
    fontSize: 62,
    marginTop: 150,
    marginBottom: 20,
  },
  buttonContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  button: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#DDDDDD',
    justifyContent: 'center',
    alignItems: 'center',
  },
  lapButton: {
    marginRight: 10,
  },
  stopButton: {
    marginLeft: 10,
    backgroundColor: 'lightgreen',
  },
  buttonText: {
    fontSize: 16,
  },
  buttonTextstop: {
    fontSize: 16,
    color: 'green',
  },
  historyContainer: {
    flex: 1,
    alignSelf: 'flex-end',
    marginRight: 150,
  },
  historyItem: {
    fontSize: 20,
    marginBottom: 10,
    color: 'white',
  },
});

export default StopwatchApp;